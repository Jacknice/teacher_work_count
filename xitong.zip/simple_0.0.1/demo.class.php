<?php
function export()
{
    $file_name   = "成绩单-".date("Y-m-d H:i:s",time());
    $file_suffix = "xls";
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=$file_name.$file_suffix");
    //根据业务，自己进行模板赋值。
    $this->display();
}