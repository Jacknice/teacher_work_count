$().ready(function () {
    //教学信息未审核数据表查询数据
    $('#table_teach_info_nopass').dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_teach_info_nopass'/>"
        }],
        "ajax": "data/teach_info_pass.php?num=1",
    });
    //教学信息已审核数据表查询数据
    $('#table_teach_info_pass').dataTable({
        "ajax": "data/teach_info_pass.php?num=3",
    });
    //实践教学信息未审核数据表查询数据
    $('#shijian_nopass').dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_shijian_nopass'/>"
        }],
        "ajax": "data/start_loading_data.php?num=5",
    });
    //实践教学信息已审核查询数据
    $('#shijian_pass').dataTable({
        "ajax": "data/start_loading_data.php?num=6",
    });
    //毕业设计信息未审核查询数据
    $('#bishe_nopass').dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_bishe'/>"
        }],
        "ajax": "data/bishen.php?num=1",
    });
    //毕业设计信息已审核查询数据
    $('#bishe_pass').dataTable({
        "ajax": "data/bishen.php?num=2",
    });
    //用户管理查询数据
    $('#user').dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_user'/>"
        },{
            "targets": -1,
            "data": null,
            "defaultContent": '<span title="修改"class="glyphicon glyphicon-pencil up_user" data-toggle="modal" data-target="#add_user"></span>&nbsp;&nbsp;&nbsp;&nbsp;<span title="删除" class="glyphicon glyphicon-trash del_user"></span>'

        }
        ],
        "ajax": "data/start_loading_data.php?num=4",
    });
    //毕业设计信息查询数据
    $('#gradution').dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_gradution'/>",
        },{
            "targets": -1,
            "data": null,
            "defaultContent": "<span data-toggle='modal' data-target='#alert_warning' title = '删除' class = 'delete glyphicon glyphicon-trash'> </span >",
        }],
        "ajax": "data/gradution.php?stu_name=1",
    });
    //额外工作量审核数据加载
    $("#ext_work_ispass").dataTable({
        "columnDefs": [{
            "targets": 0,
            "data": null,
            "defaultContent": "<input type='checkbox' class='check_ext_work'/>",
        //},
            //{
        //    "targets": 0,
        //    "data": null,
        //    "defaultContent": "<span data-toggle='modal' data-target='#alert_warning' title = '删除' class = 'delete glyphicon glyphicon-trash'> </span >",
        }],
        "ajax": "data/start_loading_data.php?num="+1,
    });
    //额外工作量已经审核数据加载
    $("#ext_work_look").dataTable({
        "ajax": "data/start_loading_data.php?num="+2,
    });
    //工作量管理数据加载
    $("#work_num_add").dataTable({
        "ajax": "data/start_loading_data.php?num="+3,
    });
    //添加用户按钮点击事件
    $("#add").on("click",function(){
        $(this).prev().click();
        var data=$('#add_u').serialize();
        var str=$("#add_user").find(".modal-title").html();
        var num=null;
        var title='';
        if(str=="修改用户"){
            num=2;
            title="修改成功";
            data=data+"&num="+num+"&uname="+th.siblings(`td:eq(1)`).text();
        }else if(str=="添加用户"){
            num=1;
            title="添加成功";
            data=data+"&num="+num;
        }
        $.ajax({
            url: "data/add_user.php",
            data: data,
            type: "POST",
            success: function (data) {
                if(data.trim()=="ok"){
                    swal({title:title,type:"success"})
                }
            }
        });
    })
    //用户管理修改图标点击事件
    $("tbody").delegate(".up_user",'click',function(){
        $("#add_user").find(".modal-title").html("修改用户");
        $("#add").html("修改");
        th=$(this).parent();
        var names=['uname','yx','zc','xl','phone'];
        for(var i=0;i<6;i++){
            $(`input[name='${names[i]}']`).val(th.siblings(`td:eq(${i+1})`).text());
        }
    });
    //用户管理删除图表点击事件
    $("tbody").delegate(".del_user",'click',function(){
        var th=$(this);
        var uname=th.parent().siblings("td:eq(1)").text();
        var url="data/delect.php?num=1&name="+uname;
        swal({title:"您确定要删除这条信息吗?",
                text:"删除后将无法恢复，请谨慎操作！",
                type:"warning",
                showCancelButton:true,confirmButtonColor:"#DD6B55",
                confirmButtonText:"删除",
                closeOnConfirm:false,
                closeOnCancel:false},
            function(isConfirm){
                if(isConfirm){
                    $.ajax({
                        url: url,
                        type: "POST",
                        success: function (data) {
                            th.parent().parent().fadeOut("slow");
                            swal("删除成功！","您已经永久删除了这条信息。","success")
                        }
                    });
                }else{
                    swal("已取消","您取消了删除操作！","error")
                }
            }
        );
    });

    //修改密码
    $("#update_upwd").on("click", function () {
        if (($("#ok_new_pwd").val()) === ($("#new_pwd").val())) {
            $.ajax({
                url: "data/update_pwd.php",
                type: "POST",
                data: "ok_new_pwd" + "=" + $("#ok_new_pwd").val(),
                success: function (data) {
                    if (data == 'sql执行成功') {
                        $("#pwd_alert > p").html('');
                        $("#pwd_alert").removeClass("alert-warning").addClass("alert-success").css("display", "block").append('<p><strong>恭喜！</strong>密码修改成功!!!</p>');
                    }
                },
            });
        } else {
            $("#pwd_alert > p").html('');
            $("#pwd_alert").removeClass("alert-warning").addClass("alert-warning").css("display", "block").append('<p><strong>警告！</strong>两次密码输入不一样!!!</p>');
        }
    });
    //一键换肤
        //从localStorge中读取mainStyle样式
    function read_style() {
        var mainStyle = localStorage.getItem("mainStyle");
        if (mainStyle != "undefined") {
            $("body").removeClass().addClass(mainStyle);
        }
        setTimeout(read_style, 1000);
    }

    read_style();
        //向localStorge中写入mainStyle样式
    function write_style() {
        var bodyClass = $("body").attr('class');
        if (bodyClass !== " pace-running") {
            localStorage.setItem("mainStyle", bodyClass);
        }
        setTimeout(write_style, 50);
    }

    write_style();
    //导航栏链接
    function navlink() {
        var target = "#" + $(this).attr("class");
        $(".right").css("display", "none");
        $(target).css("display", "block");
    }

    $(".navbar-default .nav > li > a").on("click", navlink);
    $(".dropdown-menu > li > a").on("click", navlink);
    $(".nav.navbar-top-links .link-block a").on("click", navlink);
    //头像上传实时刷新
    function head() {
        $.ajax({
            url: "http://127.0.0.1/simple_0.0.1/upload/admin.jpg",
            type: "POST",
            success: function (data) {
                $(".img-circle:first").removeAttr("src").attr("src", "http://127.0.0.1/simple_0.0.1/upload/admin.jpg");
            }
        })
    }

    function header() {
        timeId = setTimeout(head, 1000);
    }

    $(".button_upload").on("click", header);
    //全选按钮
    $("input[data-check^='check']").on('click', function () {
        var str1 = "." + $(this).attr("data-check");
        var box = $(this).prop("checked");
        if (box) {
            $(str1).prop("checked", true);
        } else {
            $(str1).prop("checked", false);
        }
    });
//数据加载
//  $(".navbar-default .nav > li > a").on("click", function () {
//      var target = $(this).attr("class");
//      if (target !== undefined) {
//          var url = "data/" + target + ".php";
//          $.ajax({
//              url: url,
//              type: "POST",
//              success: function (data) {
//                  var html = "";
//                  $.each(data, function (i, n) {
//                      html += `<tr class="gradeX">
//										<td class="text-center"><input type="checkbox" class="check01" /></td>
//										<td class="text-center">${n.teacher_id}</td>
//										<td class="text-center">${n.class_id}</td>
//										<td class="text-center">${n.class_name}</td>
//										<td class="text-center">${n.class_type}</td>
//										<td class="text-center">${n.grade}</td>
//										<td class="text-center">${n.study_hours}</td>
//										<td class="text-center">${n.week_num}</td>
//										<td class="text-center">${n.xueyuan}</td>
//										<td class="text-center">${n.banji}</td>
//										<td class="text-center">${n.ext_people}</td>
//										<td class="text-center">${n.shiji_people}</td>
//										<td class="text-center">${n.note}</td>
//										</tr>`;
//                  });
//                  $("#" + target + " table>tbody").html(html);
//              },
//              error: function (data) {
//                  alert("用户数据导入失败!!!");
//                  //                    $( '#serverResponse').html(data.status + " : " + data.statusText + " : " + data.responseText);
//              }
//          });
//      }
//
//  });
//上传xls文件
    $("[id^='up_file']").on('click', function () {
        var upload_id = $(this).attr("id");
        var data_table = '';
        if (upload_id == "up_file_0") {
            var fileObj = document.getElementById("f").files[0];
            data_table = "teach_task";
        } else if (upload_id == "up_file_1") {
            var fileObj = document.getElementById("k").files[0];
            data_table = "gradution";
        } else if (upload_id == "up_file_2") {
            var fileObj = document.getElementById("j").files[0];
            data_table = "class_info";
        }
        //var fileObj = document.getElementById("f").files[0];
        var formData = new FormData();
        formData.append("file", fileObj);
        //console.log(fileObj);
        $.ajax({
            url: "data/file_upload.php?data_table=" + data_table,
            type: "POST",
            data: formData,
            async: false,
            cache: false,
            contentType: false,
            processData: false,
            success: function (data) {
                if (data === "data_into_succ") {
                    alert("用户数据导入成功!!!");
                }
            },
            error: function (data) {
                alert("用户数据导入失败!!!");
                //                    $( '#serverResponse').html(data.status + " : " + data.statusText + " : " + data.responseText);
            }
        });
    });
//教学信息未审核通过按钮事件
    function teach_info_pass() {
        $("input[class^='check']").prop("checked", function (i, val) {
            console.log(i);
        });
    }
    //发邮件
    $("a[title='Send']").on("click",function(){
        var received=$("#send_user").val()
        var theme=$("#theme").val()
        var content=encodeURIComponent($(".note-editable").html());
        var send="管理员";
        var oDate = new Date();
        var sendtime = oDate.getTime();
        var isread="否";
        $.ajax({
            url: "data/email.php?send="+send+"&received="+received+"&theme="+theme+"&content="+content+"&sendtime="+sendtime+"&isread="+isread+"&num="+1,
            dataType : 'text',
            type: "POST",
            success: function (data) {
                if(data=="ok"){
                    alert("邮件发送成功!!!");
                }
            }
        });
    })
    //删除邮件
    $("button[data-original-title='删除邮件']").on("click",delectEmail);
    $("a[data-original-title='删除邮件']").on("click",delectEmail);
    function delectEmail(){
        var theme=$(".mail-tools:eq(1)").children("h3").children('a').html();
        var send=$(".mail-tools:eq(1)").children("h5").children('a').html();
        $.ajax({
            url: "data/email.php?send="+send+"&theme="+theme+"&num="+2,
            dataType : 'text',
            type: "POST",
            success: function (data) {
                if(data=="ok"){
                    alert("邮件删除成功!!!");
                    window.location = './index.html';
                }
            }
        });
    };
    //回复
    $("a[title='back']").on("click",function(){
        $("#mail_detail").css("display","none");
        $("#mail_compose").css("display","block");
        $("#send_user").val($(".mail-tools:eq(1)").children("h5").children('a').html());

    });
    //选择按钮点击事件
    $("tbody").delegate(".delete",'click',function(){
        th=$(this);
        stu_name=th.parent().siblings("td:eq(4)").text();
    });
    $(".de_alert").on('click',function(){
        $.ajax({
              url: "data/gradution.php?stu_name="+stu_name,
              type: "POST",
              success: function (data) {
                alert(data);
              }
        });
        th.parent().parent().fadeOut("slow");
    })
    //选择未审核表格中的最后一行隐藏
    setTimeout(hide,2000);
    function hide(){
        $("#table_teach_info_nopass").find("tbody tr td:last-child").css("display","none");
        $("#bishe_nopass").find("tbody tr td:last-child").css("display","none");
        $("#gradution").find("tbody tr td:nth-child(10)").css("display","none");
        $("#shijian_nopass").find("tbody tr td:last-child").css("display","none");
    }
})
;
