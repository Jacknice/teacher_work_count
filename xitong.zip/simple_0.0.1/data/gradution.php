<?php
/**接收客户端提交的新密码，验证是否正确，向客户端输出ok或err**/
header('Content-Type: application/json;charset=UTF-8');
//连接数据库
$data=['data'=>array(array())];
//var_dump($data[data][0][0]);
include('0_config.php'); //包含指定文件的内容在当前位置
$stu_name=$_REQUEST["stu_name"];
$stu_name=explode(',',$stu_name);
if($stu_name[0]=="1"){
       $sql = "SELECT  `g_term`, `u_name`,`g_institute`, `g_sclass`,`g_id`, `g_snumber`, `g_sname`,  `g_project`, `g_note` FROM `gradution`";
        $result = mysqli_query($conn,$sql);
        $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $array=[];
        for($i=0;$i<count($result);$i++) {
            $data['data'][$i][0]='';
            $data['data'][$i][1]=$result[$i]['g_term'];
            $data['data'][$i][2]=$result[$i]['u_name'];
            $data['data'][$i][3]=$result[$i]['g_institute'];
            $data['data'][$i][4]=$result[$i]['g_sclass'];
            $data['data'][$i][5]=$result[$i]['g_snumber'];
            $data['data'][$i][6]=$result[$i]['g_sname'];
            $data['data'][$i][7]=$result[$i]['g_project'];
            $data['data'][$i][8]=$result[$i]['g_note'];
            $data['data'][$i][9]=$result[$i]['g_id'];
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
}else{
        for($i=0,$len=count($stu_name);$i<$len;$i++){
            $sql = "DELETE FROM `gradution` WHERE g_snumber='$stu_name[$i]'";
            $result=mysqli_query($conn,$sql);
        }
        if($result){
           echo "数据已审核!!!";
        }else{
           echo "SQL语句错误!!!";
        }
}
?>