<?php
/**接收客户端提交的新密码，验证是否正确，向客户端输出ok或err**/
header('Content-Type: text/plain');
//连接数据库
include('0_config.php'); //包含指定文件的内容在当前位置
$name = $_REQUEST['name'];
$sql = "DELETE FROM `user` WHERE u_name='$name'";
$result = mysqli_query($conn,$sql);

if($result)
{
echo "ok";
}
else{
echo "error";
}

