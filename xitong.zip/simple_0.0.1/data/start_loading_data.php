<?php
/**接收客户端提交的新密码，验证是否正确，向客户端输出ok或err**/
header('Content-Type: application/json;charset=UTF-8');
//连接数据库
$num=$_REQUEST["num"];
include('0_config.php'); //包含指定文件的内容在当前位置
$data=['data'=>array(array())];
if($num=="1"){
       $sql = "SELECT  `d_term`, `d_workname`, `d_value`, `u_id` FROM `dynamic` WHERE d_state='未审核'";
       $result = mysqli_query($conn,$sql);
       $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
       $array=[];
       for($i=0;$i<count($result);$i++) {
           $data['data'][$i][0]="";
           $data['data'][$i][1]=$result[$i]['d_term'];
           $data['data'][$i][2]=$result[$i]['u_id'];
           $data['data'][$i][3]=$result[$i]['d_workname'];
           $data['data'][$i][4]=$result[$i]['d_value'];
       }
}
if($num=="2"){
       $sql = "SELECT  `d_term`, `d_workname`, `d_value`, `u_id`, `d_state` FROM `dynamic` WHERE d_state !='未审核'";
       $result = mysqli_query($conn,$sql);
       $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
       $array=[];
       for($i=0;$i<count($result);$i++) {
           $data['data'][$i][0]=$result[$i]['d_term'];
           $data['data'][$i][1]=$result[$i]['u_id'];
           $data['data'][$i][2]=$result[$i]['d_workname'];
           $data['data'][$i][3]=$result[$i]['d_value'];
           $data['data'][$i][4]=$result[$i]['d_state'];
       }
}
if($num=="3"){
       $sql = "SELECT  `u_id`, `w_term`, `w_course`, `w_cdesign`, `w_graduation`, `w_allowance`, `w_dynamic`, `w_stipulate`, `w_workload`, `w_iscomplete` FROM `workload` ";
       $result = mysqli_query($conn,$sql);
       $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
       $array=[];
       for($i=0;$i<count($result);$i++) {
           $data['data'][$i][1]=$result[$i]['u_id'];
           $data['data'][$i][0]=$result[$i]['w_term'];
           $data['data'][$i][2]=$result[$i]['w_course'];
           $data['data'][$i][3]=$result[$i]['w_cdesign'];
           $data['data'][$i][4]=$result[$i]['w_graduation'];
           $data['data'][$i][5]=$result[$i]['w_allowance'];
           $data['data'][$i][6]=$result[$i]['w_dynamic'];
           $data['data'][$i][7]=$result[$i]['w_stipulate'];
           $data['data'][$i][8]=$result[$i]['w_workload'];
           $data['data'][$i][9]=$result[$i]['w_iscomplete'];
       }
}
if($num=="4"){
       $sql = "SELECT  `u_institue`, `u_role`, `u_name`,  `u_sdept`,  `u_phone` FROM `user` WHERE u_name!='管理员'";
       $result = mysqli_query($conn,$sql);
       $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
       $array=[];
       for($i=0;$i<count($result);$i++) {
           $data['data'][$i][0]='';
           $data['data'][$i][1]=$result[$i]['u_name'];
           $data['data'][$i][2]=$result[$i]['u_institue'];
           $data['data'][$i][3]=$result[$i]['u_role'];
           $data['data'][$i][4]=$result[$i]['u_sdept'];
           $data['data'][$i][5]=$result[$i]['u_phone'];
       }
}
if($num=="5"){
           $sql = "SELECT `id`, `p_link`, `p_score`, `p_type`, `p_class`, `p_major`, `p_a_class`, `p_stunum`, `p_week`, `p_start`, `p_teacher`,`p_note` FROM `pra_work` where p_note='未审核'";
           $result = mysqli_query($conn,$sql);
           $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
           $array=[];
           for($i=0;$i<count($result);$i++) {
               $data['data'][$i][0]='';
               $data['data'][$i][1]=$result[$i]['p_link'];
               $data['data'][$i][2]=$result[$i]['p_score'];
               $data['data'][$i][3]=$result[$i]['p_type'];
               $data['data'][$i][4]=$result[$i]['p_class'];
               $data['data'][$i][5]=$result[$i]['p_major'];
               $data['data'][$i][6]=$result[$i]['p_a_class'];
               $data['data'][$i][7]=$result[$i]['p_stunum'];
               $data['data'][$i][8]=$result[$i]['p_week'];
               $data['data'][$i][9]=$result[$i]['p_start'];
               $data['data'][$i][10]=$result[$i]['p_teacher'];
               $data['data'][$i][11]=$result[$i]['p_note'];
               $data['data'][$i][12]=$result[$i]['id'];
           }
}
if($num=="6"){
           $sql = "SELECT `id`, `p_link`, `p_score`, `p_type`, `p_class`, `p_major`, `p_a_class`, `p_stunum`, `p_week`, `p_start`, `p_teacher`,`p_note` FROM `pra_work`";
           $result = mysqli_query($conn,$sql);
           $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
           $array=[];
           for($i=0;$i<count($result);$i++) {
               $data['data'][$i][0]=$result[$i]['p_link'];
               $data['data'][$i][1]=$result[$i]['p_score'];
               $data['data'][$i][2]=$result[$i]['p_type'];
               $data['data'][$i][3]=$result[$i]['p_class'];
               $data['data'][$i][4]=$result[$i]['p_major'];
               $data['data'][$i][5]=$result[$i]['p_a_class'];
               $data['data'][$i][6]=$result[$i]['p_stunum'];
               $data['data'][$i][7]=$result[$i]['p_week'];
               $data['data'][$i][8]=$result[$i]['p_start'];
               $data['data'][$i][9]=$result[$i]['p_teacher'];
               $data['data'][$i][10]=$result[$i]['p_note'];
           }
}
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>