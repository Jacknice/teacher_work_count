<?php
/**接收客户端提交的新密码，验证是否正确，向客户端输出ok或err**/
header('Content-Type: text/plain');
//连接数据库
include('0_config.php'); //包含指定文件的内容在当前位置
$num=$_REQUEST["num"];
if($num==2){
   $y_or_no=$_REQUEST["y_or_no"];
   $a=explode(',',$_REQUEST["work_name"]);
   $b=explode(',',$_REQUEST["uname"]);
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "UPDATE `dynamic` SET `d_state`='$y_or_no' WHERE u_id='$b[$i]' AND d_workname='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "数据已审核!!!";
   }else{
      echo "SQL语句错误!!!";
   }

}
if($num==1){
   $cla_name=$_REQUEST["cla_name"];
   $y_or_no=$_REQUEST["y_or_no"];
   $a=explode(',',$cla_name);
   //var_dump($result[0]);
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "UPDATE `teach_task` SET `note`='$y_or_no' WHERE id='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "数据已审核!!!";
   }else{
      echo "SQL语句错误!!!";
   }
}
if($num==3){
   $cla_name=$_REQUEST["cla_name"];
   $y_or_no=$_REQUEST["y_or_no"];
   $a=explode(',',$cla_name);
   //var_dump($result[0]);
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "UPDATE `gradution` SET`g_zt`='$y_or_no' WHERE g_id='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "数据已审核!!!";
   }else{
      echo "SQL语句错误!!!";
   }
}
if($num==4){
   $a=explode(',',$_REQUEST["uname"]);
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "DELETE FROM `user` WHERE u_name='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "ok";
   }else{
      echo "error";
   }
}
if($num==5){
   $a=explode(',',$_REQUEST["id"]);
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "DELETE FROM `gradution` WHERE g_id='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "ok";
   }else{
      echo "error";
   }
}
if($num==6){
   $a=explode(',',$_REQUEST["id"]);
   $y_or_no=$_REQUEST["y_or_no"];
   for($i=0,$len=count($a);$i<$len;$i++){
      $sql = "UPDATE `pra_work` SET `p_note`='$y_or_no' WHERE id='$a[$i]'";
      $result = mysqli_query($conn,$sql);
   }
   if($result){
      echo "ok";
   }else{
      echo "error";
   }
}
?>























