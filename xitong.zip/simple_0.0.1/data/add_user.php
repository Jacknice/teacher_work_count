<?php
/**接收客户端提交的新密码，验证是否正确，向客户端输出ok或err**/
header('Content-Type: text/plain');
//连接数据库
include('0_config.php'); //包含指定文件的内容在当前位置
$num=$_REQUEST["num"];
$name=$_REQUEST["uname"];
   $yx=$_REQUEST["yx"];
   $zc=$_REQUEST["zc"];
   $xl=$_REQUEST["xl"];
   $phone=$_REQUEST["phone"];
if($num==1){
   $sql="INSERT INTO `user`(`u_name`, `u_institue`,  `u_role`, `u_password`, `u_sdept`, `u_phone`,`u_picture`) VALUES ('$name','$yx','$zc','123456','$xl','$phone','http://127.0.0.1/teacher/upload/.$phone.jpg')";
}
if($num==2){
   $sql="UPDATE `user` SET `u_institue`='$yx',`u_role`='$zc',`u_sdept`='$xl',`u_phone`='$phone' WHERE u_name='$name'";
}
$result = mysqli_query($conn,$sql);
if($result){
    echo "ok";
}
else{
    echo "error";
}


?>